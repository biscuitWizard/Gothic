﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace SpellParser
{
    public class Technique
    {
        public List<Image> Images { get; set; }
        public string Type { get; set; }
    }
}
